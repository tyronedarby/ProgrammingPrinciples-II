/**
 * 
 */
/**
 * 
 */
module MPGCalculator {
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.media;
	exports lab10;
}